namespace Groups.Implementions;

public class StudentEntity : PersonEntity
{
    public StudentEntity(int id, string name, string email) : base(id, name, email) { }
}